<?php

namespace Dingo\Blueprint\Annotation\Method;

/**
 * @Annotation
 */
class Delete extends Method
{
}
