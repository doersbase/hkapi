<?php

namespace Dingo\Blueprint\Annotation\Method;

/**
 * @Annotation
 */
class Post extends Method
{
}
