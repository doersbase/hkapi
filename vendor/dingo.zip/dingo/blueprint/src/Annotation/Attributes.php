<?php

namespace Dingo\Blueprint\Annotation;

/**
 * @Annotation
 */
class Attributes
{
    /**
     * @array<Attribute>
     */
    public $value;
}
